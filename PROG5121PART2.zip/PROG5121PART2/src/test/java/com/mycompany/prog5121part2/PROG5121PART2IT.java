/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121part2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author nomfu
 */
public class PROG5121PART2IT {
    
    public PROG5121PART2IT() {
    }

     @Test
    public void testValidMessageID() {
        Message message = new Message(
                "1234567890", 1, "+27718693002", "Hello Mike");

        assertTrue(message.checkMessageID());
    }

    @Test
    public void testInvalidMessageID() {
        Message message = new Message(
                "ABC123", 1, "+27718693002", "Hello Mike");

        assertFalse(message.checkMessageID());
    }

    @Test
    public void testValidRecipient() {
        Message message = new Message(
                "1234567890", 1, "+27718693002", "Hello Mike");

        assertTrue(message.checkRecipientCell().contains(
                "successfully captured"));
    }

    @Test
    public void testInvalidRecipient() {
        Message message = new Message(
                "1234567890", 1, "12345", "Hello Mike");

        assertTrue(message.checkRecipientCell().contains(
                "incorrectly formatted"));
    }

    @Test
    public void testMessageHash() {
        Message message = new Message(
                "0012345678", 0, "+27718693002", "Hi tonight");

        assertEquals("00:0:HITONIGHT", message.getMessageHash());
    }

    @Test
    public void testSendMessage() {
        Message message = new Message(
                "1234567890", 1, "+27718693002", "Hello");

        assertEquals("Message successfully sent.",
                message.SentMessage(1));
        assertEquals(1, message.returnTotalMessagess());
    }

    @Test
    public void testDisregardMessage() {
        Message message = new Message(
                "1234567890", 1, "+27718693002", "Hello");

        assertEquals("Press 0 to delete the message.",
                message.SentMessage(2));
        assertEquals(0, message.returnTotalMessagess());
    }

    @Test
    public void testStoreMessageStatus() {
        Message message = new Message(
                "1234567890", 1, "+27718693002", "Hello");

        assertEquals("Message successfully stored.",
                message.SentMessage(3));
        assertEquals("Stored", message.getMessageStatus());
    }

    @Test
    public void testLoginUsernameValidation() {
        Login login = new Login(
                "jon_", "Password1!", "0821234567", "Jon", "Nya");

        assertTrue(login.checkUserName());
    }

    @Test
    public void testLoginPasswordValidation() {
        Login login = new Login(
                "jon_", "Password1!", "0821234567", "Jon", "Nya");

        assertTrue(login.checkPasswordComplexity());
    }
}