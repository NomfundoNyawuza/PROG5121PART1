/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121part2;
import java.util.Scanner;
import java.util.Random;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

/**
 *
 * @author nomfu
 */
public class PROG5121PART2 {
  
   // Used to read input from the user.
    private static final Scanner input = new Scanner(System.in);

    // Generates random numbers for message IDs.
    private static final Random random = new Random();

    // Keeps track of message IDs already generated.
    private static final Set<String> messageIds = new HashSet<>();

    // Location where messages are saved.
    private static final Path JSON_FILE = Path.of(
            System.getProperty("user.home"),
            "OneDrive",
            "Documents",
            "NetBeansProjects",
            "PROG5121PART2",
            "stored_messages.json"
    );

    
    public static void main(String[] args) {

        System.out.println("Welcome to QuickChat.");
        
    // Keep asking the user to register until successful.
         boolean registrationSuccessful = false;
         Login user = null;

        while (!registrationSuccessful) {

           System.out.println("Register a user to access QuickChat.");

           System.out.print("Enter a username: "); // Include an underscore, max 5 characters
           String newUsername = input.nextLine();

           System.out.print("Enter a password: "); // Minimum 8 characters, uppercase, number and special character.
           String newPassword = input.nextLine();

           System.out.print("Enter your cellphone number: "); //Include international code, e.g. +27821234567s. 
           String newCellphone = input.nextLine();

           System.out.print("Enter your first name: ");
           String newFirstName = input.nextLine();

           System.out.print("Enter your last name: ");
           String newLastName = input.nextLine();

            // Create the user account.
            user = new Login(
            newUsername,
            newPassword,
            newCellphone,
            newFirstName,
            newLastName
    );

           // Check whether registration was successful.
           String registrationResult = user.registerUser();
           System.out.println(registrationResult);

       if (registrationResult.equals("User has been registered successfully.")) {
        registrationSuccessful = true;
    } else {
           System.out.println("Please try registering again.\n");
    }
}

        // Keep asking for login details until login succeeds.
        boolean loginSuccessful = false;

        while (!loginSuccessful) {

            System.out.print("Enter username to log in: ");
            String username = input.nextLine();

            System.out.print("Enter password to log in: ");
            String password = input.nextLine();

           loginSuccessful = user.loginUser(username, password);

            System.out.println(user.returnLoginStatus(loginSuccessful));
}

        
        int choice = 0;

        // Display the main menu until the user chooses to quit.
        while (choice != 3) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");

            choice = readInteger();

            switch (choice) {
                case 1:
                    sendMessages();
                    break;

                case 2:
                    System.out.println("Coming Soon.");
                    break;

                case 3:
                    System.out.println("Goodbye.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    // Allows the user to create and manage messages.
    private static void sendMessages() {

        int numberOfMessages;

        // Make sure the user enters at least one message.
        do {
            System.out.print(
                    "How many messages would you like to enter? ");

            numberOfMessages = readInteger();

            if (numberOfMessages < 1) {
                System.out.println(
                        "Please enter at least one message.");
            }

        } while (numberOfMessages < 1);

        int totalMessagesSent = 0;

        // Repeat the message process for the chosen number of messages.
        for (int i = 1; i <= numberOfMessages; i++) {

            System.out.println("\nPreparing message " + i);

            String recipient;

            // Check that the recipient's cellphone number is valid.
            do {
                System.out.print(
                        "Enter recipient cellphone number: ");

                recipient = input.nextLine();

                Message validationMessage = new Message(
                        "1234567890", i, recipient, "Test message");

                if (!recipient.matches("\\+27\\d{9}")
                        && !recipient.matches("0\\d{9}")) {
                    System.out.println(
                            validationMessage.checkRecipientCell());
                }

            } while (!isValidRecipient(recipient));

            String message;

            // Make sure the message is not empty or too long.
            do {
                System.out.print("Enter your message: ");
                message = input.nextLine();

                if (message.trim().isEmpty()) {
                    System.out.println("Please enter a message.");
                } else if (message.length() >= 250) {
                    System.out.println(
                            "Please enter a message of less than 250 characters.");
                }

            } while (message.trim().isEmpty()
                    || message.length() >= 250);

            // Generate an ID and create the message.
            String messageId = generateMessageId();

            Message currentMessage = new Message(
                    messageId, i, recipient, message);

            // Ask the user what to do with the message.
            System.out.println("\n1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message");
            System.out.print("Choose what to do with this message: ");

            int messageChoice = readInteger();

            if (messageChoice == 1) {

                // Send the message and display its details.
                System.out.println(currentMessage.SentMessage(1));

                System.out.println(currentMessage.printMessages());

                totalMessagesSent++;

            } else if (messageChoice == 2) {

                // Disregard the message.
                System.out.print("Enter 0 to delete the message: ");
                int deleteChoice = readInteger();

                if (deleteChoice == 0) {
                    System.out.println("Message disregarded and deleted.");
                } else {
                    System.out.println("Message deletion cancelled.");
                }

            } else if (messageChoice == 3) {

                // Save the message to the JSON file.
                System.out.println(
                        currentMessage.SentMessage(3));

                if (storeMessage(currentMessage)) {
                    System.out.println("Message successfully stored.");
                } else {
                    System.out.println("Message could not be stored.");
                }

            } else {
                System.out.println("Invalid option.");
            }
        }

        // Display the total number of messages sent.
        System.out.println("\nTotal messages successfully sent: " + totalMessagesSent);
    }

    // Generates a unique message ID.
    private static String generateMessageId() {

        String messageId;

        do {
            long generatedId = 1_000_000_000L
                    + random.nextInt(900_000_000);

            messageId = String.valueOf(generatedId);

        } while (messageIds.contains(messageId));

        messageIds.add(messageId);

        return messageId;
    }

    
    // Checks whether the cellphone number has a valid format.
    private static boolean isValidRecipient(String recipient) {
        return recipient != null
                && recipient.matches("\\+27[678]\\d{8}");
    }


    // Saves a message to the JSON file.
    private static boolean storeMessage(Message message) {

        try {
            // Create the folder if it does not exist.
            Path parent = JSON_FILE.getParent();

            if (parent != null) {
                Files.createDirectories(parent);
            }

            ArrayList<String> records = new ArrayList<>();

            // Load messages that have already been saved.
            if (Files.exists(JSON_FILE)) {
                String existingJson = Files.readString(JSON_FILE);
                records.addAll(extractJsonObjects(existingJson));
            }

            // Avoid adding the same message ID twice.
            for (String record : records) {
                if (record.contains(
                        "\"messageID\": \""
                        + escapeJson(message.getMessageID()) + "\"")) {
                    System.out.println( "This message is already stored.");
                    return true;
                }
            }

            // Build the JSON record for the new message.
            String record = "  {\n"
                    + "    \"messageID\": \""
                    + escapeJson(message.getMessageID()) + "\",\n"
                    + "    \"messageNumber\": "
                    + message.getMessageNumber() + ",\n"
                    + "    \"recipient\": \""
                    + escapeJson(message.getRecipient()) + "\",\n"
                    + "    \"message\": \""
                    + escapeJson(message.getMessage()) + "\",\n"
                    + "    \"messageHash\": \""
                    + escapeJson(message.getMessageHash()) + "\"\n"
                    + "  }";

            records.add(record);

            // Combine all messages into one JSON array.
            StringBuilder json = new StringBuilder("[\n");

            for (int i = 0; i < records.size(); i++) {
                json.append(records.get(i));

                if (i < records.size() - 1) {
                    json.append(",");
                }

                json.append("\n");
            }

            json.append("]");

            // Write the updated messages to the file.
            Files.writeString(JSON_FILE, json.toString());

            System.out.println(
                    "JSON file saved to: "
                    + JSON_FILE.toAbsolutePath());

            return true;

        } catch (IOException e) {
            // Display an error if the file cannot be saved.
            System.out.println(
                    "JSON storage error: " + e.getMessage());
            return false;
        }
    }

    // Reads individual JSON objects from the existing JSON array.
    private static ArrayList<String> extractJsonObjects(String json) {

        ArrayList<String> objects = new ArrayList<>();

        int depth = 0;
        int start = -1;
        boolean insideString = false;
        boolean escaped = false;

        // Find each complete JSON object in the file.
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);

            if (insideString) {
                if (escaped) {
                    escaped = false;
                } else if (c == '\\') {
                    escaped = true;
                } else if (c == '"') {
                    insideString = false;
                }

                continue;
            }

            if (c == '"') {
                insideString = true;
            } else if (c == '{') {
                if (depth == 0) {
                    start = i;
                }
                depth++;
            } else if (c == '}') {
                depth--;

                if (depth == 0 && start >= 0) {
                    objects.add(
                            json.substring(start, i + 1).trim());
                    start = -1;
                }
            }
        }

        return objects;
    }

    // Escapes special characters before saving text as JSON.
    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Reads an integer and asks again if the input is not a number.
    private static int readInteger() {

        while (!input.hasNextInt()) {
            System.out.print("Please enter a number: ");
            input.nextLine();
        }

        int number = input.nextInt();
        input.nextLine();

        return number;
    }
}