/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121part2;
import java.util.Locale;

/**
 *
 * @author nomfu
 */
public class Message {

    // Stores the message details.
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus;

    // Sets the message details and creates its hash.
    public Message(String messageID, int messageNumber, String recipient, String message) {

        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
        this.messageStatus = "Pending";
    }

    // Checks that the message ID contains 1 to 10 digits.
    public boolean checkMessageID() {
        return messageID != null
                && messageID.matches("\\d{1,10}");
    }

    // Checks whether the recipient's cellphone number is valid.
    public String checkRecipientCell() {
        if (recipient != null
                && (recipient.matches("\\+27[678]\\d{8}")
                || recipient.matches("0[678]\\d{8}"))) {

            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    // Creates a hash using the first two ID digits,
    // message number, first word and last word.
    public String createMessageHash() {

        // Checks that the ID and message can be used.
        if (messageID == null || messageID.length() < 2
                || message == null || message.trim().isEmpty()) {
            return "";
        }

        // Splits the message into words.
        String[] words = message.trim().split("\\s+");

        // Removes punctuation from the first and last words.
        String firstWord = words[0]
                .replaceAll("[^a-zA-Z0-9]", "");

        String lastWord = words[words.length - 1]
                .replaceAll("[^a-zA-Z0-9]", "");

        // Combines the parts of the message hash.
        return messageID.substring(0, 2)
                + ":" + messageNumber
                + ":" + firstWord.toUpperCase(Locale.ROOT)
                + lastWord.toUpperCase(Locale.ROOT);
    }

    // Handles the user's choice for the message.
    public String SentMessage(int choice) {

        if (choice == 1) {
            messageStatus = "Sent";
            return "Message successfully sent.";

        } else if (choice == 2) {
            messageStatus = "Disregarded";
            return "Press 0 to delete the message.";

        } else if (choice == 3) {
            messageStatus = "Stored";
            return "Message successfully stored.";
        }

        // Returns an error for an invalid choice.
        return "Invalid option.";
    }

    // Displays the message details.
    public String printMessages() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    // Returns 1 if the message was sent, otherwise 0.
    public int returnTotalMessagess() {
        return "Sent".equals(messageStatus) ? 1 : 0;
    }

    // Returns the message ID.
    public String getMessageID() {
        return messageID;
    }

    // Returns the message number.
    public int getMessageNumber() {
        return messageNumber;
    }

    // Returns the recipient's cellphone number.
    public String getRecipient() {
        return recipient;
    }

    // Returns the message text.
    public String getMessage() {
        return message;
    }

    // Returns the message hash.
    public String getMessageHash() {
        return messageHash;
    }

    // Returns the current message status.
    public String getMessageStatus() {
        return messageStatus;
    }
}
