/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121part2;

/**
 *
 * @author nomfu
 */
public class Login {
    
    // Stores the user's details.
    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    // Saves the user's details when creating a Login object.
    public Login(String username, String password, String cellPhoneNumber, String firstName, String lastName) {

        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Checks that the username contains an underscore and is no longer than five characters.
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    // Checks that the password has at least eight characters, an uppercase letter, a number and a special character.
    public boolean checkPasswordComplexity() {
        return password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[0-9].*")
                && password.matches(".*[^a-zA-Z0-9].*");
    }

    // Checks that the cellphone number uses +27 followed by nine digits.
    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber.matches("\\+27[678]\\d{8}");
    }

    // Checks the user's details before completing registration.
    public String registerUser() {

        // Checks the username format.
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        // Checks the password requirements.
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        // Checks the cellphone number format.
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // Confirms that registration was successful.
        return "User has been registered successfully.";
    }

    // Checks whether the entered login details match the registered details.
    public boolean loginUser(String username, String password) {
        return this.username.equals(username)
                && this.password.equals(password);
    }

    // Displays a message based on the login result.
    public String returnLoginStatus(boolean loginSuccessful) {

        if (loginSuccessful) {
            return "Welcome " + firstName + " " + lastName
                    + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
    
