/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121part3;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author nomfu
 */
public class MessageManagerIT {
    
    public MessageManagerIT() {
    }

  // Location of the JSON file stored in the Part 3 project folder.
private final Path jsonFile = Path.of(
        System.getProperty("user.dir"),
        "stored_messages.json"
); 

private Path backupFile;

@BeforeEach
public void backupStoredMessages() throws IOException {

    if (Files.exists(jsonFile)) {
        backupFile = Files.createTempFile("stored-messages-backup", ".json");
        Files.copy(jsonFile, backupFile,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    } else {
        backupFile = null;
    }

    Files.createDirectories(jsonFile.getParent());
    Files.writeString(jsonFile, "[]");
}

@AfterEach
public void restoreStoredMessages() throws IOException {

    if (backupFile != null && Files.exists(backupFile)) {
        Files.copy(backupFile, jsonFile,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        Files.deleteIfExists(backupFile);
    } else {
        Files.deleteIfExists(jsonFile);
    }
}
     // Tests whether messages are added to the correct arrays.
    @Test
    public void testAddMessage() {

        MessageManager manager = new MessageManager();

        Message sent = new Message(
                "ID001", 1, "+27834557896", "Sent message"
        );
        sent.SentMessage(1);

        Message disregarded = new Message(
                "ID002", 2, "+27834557897", "Disregarded message"
        );
        disregarded.SentMessage(2);

        Message stored = new Message(
                "ID003", 3, "+27834557898",
                "Stored message", "Nomfundo"
        );
        stored.SentMessage(3);

        manager.addMessage(sent);
        manager.addMessage(disregarded);
        manager.addMessage(stored);

        assertEquals(1, manager.getSentMessages().length);
        assertEquals(1, manager.getDisregardedMessages().length);
        assertEquals(1, manager.getStoredMessages().length);
        assertEquals(3, manager.getMessageIDs().length);
        assertEquals(3, manager.getMessageHashes().length);
    }

    // Tests whether stored messages can be loaded from JSON.
    @Test
    public void testLoadStoredMessages() {

        MessageManager manager = new MessageManager();

        Message stored = new Message(
                "ID004", 4, "+27834557899",
                "Testing stored message", "Nomfundo"
        );
        stored.SentMessage(3);

        manager.addMessage(stored);

        MessageManager loadedManager = new MessageManager();

        assertEquals(1, loadedManager.getStoredMessages().length);

        assertEquals(
                "Testing stored message",
                loadedManager.getStoredMessages()[0].getMessage()
        );
    }

    // Tests whether the sender and recipient are displayed.
    @Test
    public void testDisplayStoredSendersAndRecipients() {

        MessageManager manager = new MessageManager();

        Message stored = new Message(
                "ID005", 5, "+27834557890",
                "Hello there", "Nomfundo"
        );
        stored.SentMessage(3);

        manager.addMessage(stored);

        String result = manager.displayStoredSendersAndRecipients();

        assertTrue(result.contains("Nomfundo"));
        assertTrue(result.contains("+27834557890"));
    }

    // Tests whether the longest stored message is displayed.
    @Test
    public void testDisplayLongestStoredMessage() {

        MessageManager manager = new MessageManager();

        Message first = new Message(
                "ID006", 6, "+27834557890",
                "Short message", "Nomfundo"
        );
        first.SentMessage(3);

        Message second = new Message(
                "ID007", 7, "+27834557891",
                "Where are you? You are late! I have asked you to be on time.",
                "Nomfundo"
        );
        second.SentMessage(3);

        manager.addMessage(first);
        manager.addMessage(second);

        String result = manager.displayLongestStoredMessage();

        assertTrue(result.contains(
                "Where are you? You are late! I have asked you to be on time."
        ));
    }

    // Tests searching for a stored message using its ID.
    @Test
    public void testSearchStoredMessageByID() {

        MessageManager manager = new MessageManager();

        Message stored = new Message(
                "ID008", 8, "+27834557892",
                "Message to search", "Nomfundo"
        );
        stored.SentMessage(3);

        manager.addMessage(stored);

        Message result = manager.searchStoredMessageByID("ID008");

        assertNotNull(result);
        assertEquals("Message to search", result.getMessage());
        assertEquals("+27834557892", result.getRecipient());
    }

    // Tests searching for stored messages using a recipient number.
    @Test
    public void testSearchStoredMessagesByRecipient() {

        MessageManager manager = new MessageManager();

        Message first = new Message(
                "ID009", 9, "+27838884567",
                "Where are you? You are late!", "Nomfundo"
        );
        first.SentMessage(3);

        Message second = new Message(
                "ID010", 10, "+27838884567",
                "Ok, I am leaving without you.", "Nomfundo"
        );
        second.SentMessage(3);

        Message third = new Message(
                "ID011", 11, "+27834557890",
                "Different recipient", "Nomfundo"
        );
        third.SentMessage(3);

        manager.addMessage(first);
        manager.addMessage(second);
        manager.addMessage(third);

        String result = manager.searchStoredMessagesByRecipient(
                "+27838884567"
        );

        assertTrue(result.contains("Where are you? You are late!"));
        assertTrue(result.contains("Ok, I am leaving without you."));
        assertFalse(result.contains("Different recipient"));
    }

    // Tests deleting a stored message using its hash.
    @Test
    public void testDeleteStoredMessageByHash() {

        MessageManager manager = new MessageManager();

        Message first = new Message(
                "ID012", 12, "+27834557890",
                "Message to delete", "Nomfundo"
        );
        first.SentMessage(3);

        Message second = new Message(
                "ID013", 13, "+27834557891",
                "Message to keep", "Nomfundo"
        );
        second.SentMessage(3);

        manager.addMessage(first);
        manager.addMessage(second);

        String hash = first.getMessageHash();

        String result = manager.deleteStoredMessageByHash(hash);

        assertEquals("Message successfully deleted.", result);
        assertEquals(1, manager.getStoredMessages().length);

        assertEquals(
                "ID013",
                manager.getStoredMessages()[0].getMessageID()
        );
    }

    // Tests whether the stored message report contains message details.
    @Test
    public void testDisplayStoredMessageReport() {

        MessageManager manager = new MessageManager();

        Message stored = new Message(
                "ID014", 14, "+27834557890",
                "Report test message", "Nomfundo"
        );
        stored.SentMessage(3);

        manager.addMessage(stored);

        String result = manager.displayStoredMessageReport();

        assertTrue(result.contains("STORED MESSAGE REPORT"));
        assertTrue(result.contains("ID014"));
        assertTrue(result.contains("+27834557890"));
        assertTrue(result.contains("Report test message"));
        assertTrue(result.contains(stored.getMessageHash()));
        assertTrue(result.contains("Stored"));
    }

    // Tests whether the Sent Messages array is correctly populated.
    @Test
    public void testGetSentMessages() {

        MessageManager manager = new MessageManager();

        Message message1 = new Message(
                "ID001", 1, "+27834557896",
                "Did you get the cake?"
        );
        message1.SentMessage(1);

        Message message4 = new Message(
                "0838884567", 4, "0838884567",
                "It is dinner time!"
        );
        message4.SentMessage(1);

        manager.addMessage(message1);
        manager.addMessage(message4);

        assertEquals(2, manager.getSentMessages().length);

        assertEquals(
                "Did you get the cake?",
                manager.getSentMessages()[0].getMessage()
        );

        assertEquals(
                "It is dinner time!",
                manager.getSentMessages()[1].getMessage()
        );
    }

    // Tests whether the Disregarded Messages array is populated.
    @Test
    public void testGetDisregardedMessages() {

        MessageManager manager = new MessageManager();

        Message message = new Message(
                "ID015", 15, "+27834557890",
                "Disregarded message"
        );
        message.SentMessage(2);

        manager.addMessage(message);

        assertEquals(1, manager.getDisregardedMessages().length);

        assertEquals(
                "Disregarded message",
                manager.getDisregardedMessages()[0].getMessage()
        );
    }

    // Tests whether the Stored Messages array is populated.
    @Test
    public void testGetStoredMessages() {

        MessageManager manager = new MessageManager();

        Message message = new Message(
                "ID016", 16, "+27834557890",
                "Stored message", "Nomfundo"
        );
        message.SentMessage(3);

        manager.addMessage(message);

        assertEquals(1, manager.getStoredMessages().length);

        assertEquals(
                "Stored message",
                manager.getStoredMessages()[0].getMessage()
        );
    }

    // Tests whether the message hashes array is populated.
    @Test
    public void testGetMessageHashes() {

        MessageManager manager = new MessageManager();

        Message sent = new Message(
                "ID017", 17, "+27834557890", "Sent message"
        );
        sent.SentMessage(1);

        Message disregarded = new Message(
                "ID018", 18, "+27834557891", "Disregarded message"
        );
        disregarded.SentMessage(2);

        Message stored = new Message(
                "ID019", 19, "+27834557892",
                "Stored message", "Nomfundo"
        );
        stored.SentMessage(3);

        manager.addMessage(sent);
        manager.addMessage(disregarded);
        manager.addMessage(stored);

        String[] expected = {
            sent.getMessageHash(),
            disregarded.getMessageHash(),
            stored.getMessageHash()
        };

        assertArrayEquals(expected, manager.getMessageHashes());
    }

    // Tests whether the message IDs array is populated.
    @Test
    public void testGetMessageIDs() {

        MessageManager manager = new MessageManager();

        Message sent = new Message(
                "ID020", 20, "+27834557890", "Sent message"
        );
        sent.SentMessage(1);

        Message disregarded = new Message(
                "ID021", 21, "+27834557891", "Disregarded message"
        );
        disregarded.SentMessage(2);

        Message stored = new Message(
                "ID022", 22, "+27834557892",
                "Stored message", "Nomfundo"
        );
        stored.SentMessage(3);

        manager.addMessage(sent);
        manager.addMessage(disregarded);
        manager.addMessage(stored);

        String[] expected = {
            "ID020",
            "ID021",
            "ID022"
        };

        assertArrayEquals(expected, manager.getMessageIDs());
    }
}