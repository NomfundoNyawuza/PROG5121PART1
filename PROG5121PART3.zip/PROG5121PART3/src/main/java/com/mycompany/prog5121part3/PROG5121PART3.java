/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121part3;
import java.util.Random;
import java.util.Scanner;
import java.util.HashSet;
import java.util.Set;
/**
 *
 * @author nomfu
 */
public class PROG5121PART3 {

    private static final Scanner input = new Scanner(System.in);
    private static final Random random = new Random();
    private static final Set<String> messageIds = new HashSet<>();
    private static final MessageManager manager = new MessageManager();
    
    public static void main(String[] args) {

         System.out.println("Welcome to QuickChat.");

        // Register the user.
        boolean registrationSuccessful = false;
        Login user = null;

        while (!registrationSuccessful) {

            System.out.println("\nRegister a user to access QuickChat.");

            System.out.print("Enter a username: ");
            String username = input.nextLine();

            System.out.print("Enter a password: ");
            String password = input.nextLine();

            System.out.print("Enter your cellphone number: ");
            String cellphone = input.nextLine();

            System.out.print("Enter your first name: ");
            String firstName = input.nextLine();

            System.out.print("Enter your last name: ");
            String lastName = input.nextLine();

            user = new Login(
                    username,
                    password,
                    cellphone,
                    firstName,
                    lastName
            );

            String result = user.registerUser();

            System.out.println(result);

            if (result.equals("User has been registered successfully.")) {

                registrationSuccessful = true;

            } else {
                System.out.println("Please try registering again.");
            }
        }

        // Log in the registered user.
        boolean loginSuccessful = false;

        while (!loginSuccessful) {

            System.out.print("\nEnter username to log in: ");
            String username = input.nextLine();

            System.out.print("Enter password to log in: ");
            String password = input.nextLine();

            loginSuccessful = user.loginUser(username, password);

            System.out.println(
                    user.returnLoginStatus(loginSuccessful)
            );
        }

        // Display the main menu.
        int choice = 0;

        while (choice != 4) {

            System.out.println("\n QUICKCHAT MENU");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Stored Messages");
            System.out.println("4) Quit");
            System.out.print("Choose an option: ");

            choice = readInteger();

            switch (choice) {

                case 1:
                    sendMessages(user);
                    break;

                case 2:
                    displaySentMessages();
                    break;

                case 3:
                    storedMessagesMenu();
                    break;

                case 4:
                    System.out.println("Goodbye.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    // Allows the user to create and manage messages.
    private static void sendMessages(Login user) {

        int numberOfMessages;

        do {
            System.out.print(
                    "\nHow many messages would you like to enter? ");

            numberOfMessages = readInteger();

            if (numberOfMessages < 1) {
                System.out.println("Please enter at least one message.");
            }

        } while (numberOfMessages < 1);

        int totalMessagesSent = 0;

        for (int i = 1; i <= numberOfMessages; i++) {

            System.out.println("\nPreparing message " + i);

            String recipient;

            do {
                System.out.print("Enter recipient cellphone number: ");
                recipient = input.nextLine();

                Message validationMessage = new Message(
                        "1234567890", i, recipient, "Test message"
                );

                if (!recipient.matches("\\+27[678]\\d{8}")) {
                    System.out.println(
                            validationMessage.checkRecipientCell()
                    );
                }

            } while (!isValidRecipient(recipient));

            String message;

            do {
                System.out.print("Enter your message: ");
                message = input.nextLine();

                if (message.trim().isEmpty()) {
                    System.out.println("Please enter a message.");

                } else if (message.length() >= 250) {
                    System.out.println(
                            "Please enter a message of less than 250 characters."
                    );
                }

            } while (message.trim().isEmpty()
                    || message.length() >= 250);

            String messageId = generateMessageId();

            // Creates the message with the logged-in user's name.
            Message currentMessage = new Message(
                    messageId,
                    i,
                    recipient,
                    message,
                    user.getFirstName() + " " + user.getLastName()
            );

            System.out.println("\n1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message");
            System.out.print("Choose what to do with this message: ");

            int messageChoice = readInteger();

            if (messageChoice == 1) {

                System.out.println(currentMessage.SentMessage(1));

                manager.addMessage(currentMessage);

                System.out.println(currentMessage.printMessages());

                totalMessagesSent++;

            } else if (messageChoice == 2) {

                System.out.println(currentMessage.SentMessage(2));

                manager.addMessage(currentMessage);

                System.out.print("Enter 0 to delete the message: ");
                int deleteChoice = readInteger();

                if (deleteChoice == 0) {
                    System.out.println(
                            "Message disregarded and deleted."
                    );
                } else {
                    System.out.println(
                            "Message deletion cancelled."
                    );
                }

            } else if (messageChoice == 3) {

               currentMessage.SentMessage(3);

                  manager.addMessage(currentMessage);

                System.out.println("Message successfully stored.");

            } else {

                System.out.println("Invalid option.");
            }
        }

        System.out.println(
                "\nTotal messages successfully sent: "
                + totalMessagesSent
        );
    }

    // Displays messages sent during the current session.
    private static void displaySentMessages() {

        Message[] messages = manager.getSentMessages();

        if (messages.length == 0) {
            System.out.println("There are no sent messages.");
            return;
        }

        System.out.println("\n SENT MESSAGES");

        for (Message message : messages) {
            System.out.println(message.printMessages());
            System.out.println();
        }
    }

    // Displays the stored messages menu.
    private static void storedMessagesMenu() {

        int choice = 0;

        while (choice != 7) {

            System.out.println("\n STORED MESSAGES");
            System.out.println("1) Display senders and recipients");
            System.out.println("2) Display the longest stored message");
            System.out.println("3) Search for a message by ID");
            System.out.println("4) Search messages by recipient");
            System.out.println("5) Delete a message using its hash");
            System.out.println("6) Display stored messages report");
            System.out.println("7) Return to main menu");
            System.out.print("Choose an option: ");

            choice = readInteger();

            switch (choice) {

                case 1:
                    System.out.println(
                            manager.displayStoredSendersAndRecipients()
                    );
                    break;

                case 2:
                    System.out.println(
                            manager.displayLongestStoredMessage()
                    );
                    break;

                case 3:
                    searchMessageByID();
                    break;

                case 4:
                    searchMessagesByRecipient();
                    break;

                case 5:
                    deleteMessageByHash();
                    break;

                case 6:
                    System.out.println(
                            manager.displayStoredMessageReport()
                    );
                    break;

                case 7:
                    System.out.println("Returning to main menu.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    // Searches for a stored message using its ID.
    private static void searchMessageByID() {

        System.out.print("Enter the message ID: ");
        String id = input.nextLine();

        Message message = manager.searchStoredMessageByID(id);

        if (message == null) {
            System.out.println("Message ID not found.");

        } else {
            System.out.println("Recipient: " + message.getRecipient());
            System.out.println("Message: " + message.getMessage());
        }
    }

    // Searches for stored messages using a recipient number.
    private static void searchMessagesByRecipient() {

        System.out.print("Enter recipient cellphone number: ");
        String recipient = input.nextLine();

        System.out.println(
                manager.searchStoredMessagesByRecipient(recipient)
        );
    }

    // Deletes a stored message using its hash.
    private static void deleteMessageByHash() {

        System.out.print("Enter the message hash: ");
        String hash = input.nextLine();

        System.out.println(
                manager.deleteStoredMessageByHash(hash)
        );
    }

    // Generates a unique message ID.
    private static String generateMessageId() {

        String messageId;

        do {
            long generatedId = 1_000_000_000L
                    + random.nextInt(900_000_000);

            messageId = String.valueOf(generatedId);

        } while (messageIds.contains(messageId));

        messageIds.add(messageId);

        return messageId;
    }

    // Checks whether the recipient cellphone number is valid.
    private static boolean isValidRecipient(String recipient) {

        return recipient != null
                && recipient.matches("\\+27[678]\\d{8}");
    }

    // Reads an integer and rejects invalid input.
    private static int readInteger() {

        while (!input.hasNextInt()) {

            System.out.print("Please enter a number: ");
            input.nextLine();
        }

        int number = input.nextInt();
        input.nextLine();

        return number;
    }
}