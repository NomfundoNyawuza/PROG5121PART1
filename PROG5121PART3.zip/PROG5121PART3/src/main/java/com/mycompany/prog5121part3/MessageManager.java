/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121part3;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
/**
 *
 * @author nomfu
 */
public class MessageManager {
    
 // Location of the JSON file stored in the Part 3 project folder.
private static final Path JSON_FILE = Path.of(
        System.getProperty("user.dir"),
        "stored_messages.json"
    );

// Arrays used to manage messages.
    private Message[] sentMessages;
    private Message[] disregardedMessages;
    private Message[] storedMessages;

    private String[] messageHashes;
    private String[] messageIDs;

    // Creates empty arrays and loads stored messages.
    public MessageManager() {

        sentMessages = new Message[0];
        disregardedMessages = new Message[0];
        storedMessages = new Message[0];

        messageHashes = new String[0];
        messageIDs = new String[0];

        loadStoredMessages();
    }

    // Adds a message to the correct array.
    public void addMessage(Message message) {

        if (message == null) {
            return;
        }

        String status = message.getMessageStatus();

        if ("Sent".equals(status)) {

            sentMessages = addToMessageArray(sentMessages, message);

        } else if ("Disregarded".equals(status)) {

            disregardedMessages =
                    addToMessageArray(disregardedMessages, message);

        } else if ("Stored".equals(status)) {

            storedMessages = addToMessageArray(storedMessages, message);

            if (!saveStoredMessages()) {
                System.out.println(
                        "Message could not be saved to the JSON file."
                );
            }
        }

        updateMessageDetails();
    }

    // Adds a message to an array without hard-coding its size.
    private Message[] addToMessageArray(
            Message[] currentArray, Message message) {

        Message[] newArray =
                new Message[currentArray.length + 1];

        System.arraycopy(
                currentArray, 0,
                newArray, 0,
                currentArray.length
        );

        newArray[currentArray.length] = message;

        return newArray;
    }

    // Updates the message hash and ID arrays.
    private void updateMessageDetails() {

        ArrayList<String> hashes = new ArrayList<>();
        ArrayList<String> ids = new ArrayList<>();

        addDetailsFromArray(sentMessages, hashes, ids);
        addDetailsFromArray(disregardedMessages, hashes, ids);
        addDetailsFromArray(storedMessages, hashes, ids);

        messageHashes = hashes.toArray(new String[0]);
        messageIDs = ids.toArray(new String[0]);
    }

    // Collects hashes and IDs from a message array.
    private void addDetailsFromArray(
            Message[] messages,
            ArrayList<String> hashes,
            ArrayList<String> ids) {

        for (Message message : messages) {

            hashes.add(message.getMessageHash());
            ids.add(message.getMessageID());
        }
    }

    // Reads stored messages from the JSON file.
    public void loadStoredMessages() {

        storedMessages = new Message[0];

        try {

            if (!Files.exists(JSON_FILE)) {
                updateMessageDetails();
                return;
            }

            String json = Files.readString(JSON_FILE);

            ArrayList<String> records = extractJsonObjects(json);

            for (String record : records) {

                String id = getJsonString(record, "messageID");
                String recipient = getJsonString(record, "recipient");
                String messageText = getJsonString(record, "message");
                String sender = getJsonString(record, "sender");

                int number = getJsonInteger(
                        record, "messageNumber"
                );

                if (id == null || recipient == null
                        || messageText == null) {
                    continue;
                }

                // Creates the message with its saved details.
                Message message = new Message(
                        id,
                        number,
                        recipient,
                        messageText,
                        sender == null ? "Unknown" : sender
                );

                // Restores the stored message status.
                message.SentMessage(3);

                storedMessages =
                        addToMessageArray(storedMessages, message);
            }

            updateMessageDetails();

        } catch (IOException e) {

            System.out.println(
                    "Could not load stored messages: "
                    + e.getMessage()
            );
        }
    }

    // Extracts individual JSON objects from the JSON array.
    private ArrayList<String> extractJsonObjects(String json) {

        ArrayList<String> objects = new ArrayList<>();

        int depth = 0;
        int start = -1;

        boolean insideString = false;
        boolean escaped = false;

        for (int i = 0; i < json.length(); i++) {

            char c = json.charAt(i);

            if (insideString) {

                if (escaped) {
                    escaped = false;

                } else if (c == '\\') {
                    escaped = true;

                } else if (c == '"') {
                    insideString = false;
                }

                continue;
            }

            if (c == '"') {

                insideString = true;

            } else if (c == '{') {

                if (depth == 0) {
                    start = i;
                }

                depth++;

            } else if (c == '}') {

                depth--;

                if (depth == 0 && start >= 0) {

                    objects.add(
                            json.substring(start, i + 1).trim()
                    );

                    start = -1;
                }
            }
        }

        return objects;
    }

    // Gets a string value from a JSON object.
    private String getJsonString(String json, String key) {

        String search = "\"" + key + "\"";
        int keyPosition = json.indexOf(search);

        if (keyPosition < 0) {
            return null;
        }

        int colon = json.indexOf(':', keyPosition);

        if (colon < 0) {
            return null;
        }

        int start = json.indexOf('"', colon + 1);

        if (start < 0) {
            return null;
        }

        StringBuilder value = new StringBuilder();
        boolean escaped = false;

        for (int i = start + 1; i < json.length(); i++) {

            char c = json.charAt(i);

            if (escaped) {

                switch (c) {
                    case 'n':
                        value.append('\n');
                        break;
                    case 'r':
                        value.append('\r');
                        break;
                    case 't':
                        value.append('\t');
                        break;
                    case '"':
                        value.append('"');
                        break;
                    case '\\':
                        value.append('\\');
                        break;
                    default:
                        value.append(c);
                }

                escaped = false;

            } else if (c == '\\') {

                escaped = true;

            } else if (c == '"') {

                return value.toString();

            } else {

                value.append(c);
            }
        }

        return null;
    }

    // Gets an integer value from a JSON object.
    private int getJsonInteger(String json, String key) {

        String search = "\"" + key + "\"";
        int keyPosition = json.indexOf(search);

        if (keyPosition < 0) {
            return 0;
        }

        int colon = json.indexOf(':', keyPosition);

        if (colon < 0) {
            return 0;
        }

        int start = colon + 1;

        while (start < json.length()
                && Character.isWhitespace(json.charAt(start))) {
            start++;
        }

        int end = start;

        while (end < json.length()
                && Character.isDigit(json.charAt(end))) {
            end++;
        }

        try {

            return Integer.parseInt(json.substring(start, end));

        } catch (NumberFormatException e) {

            return 0;
        }
    }

    // Displays the sender and recipient of stored messages.
    public String displayStoredSendersAndRecipients() {

        StringBuilder report = new StringBuilder();

        if (storedMessages.length == 0) {
            return "There are no stored messages.";
        }

        for (Message message : storedMessages) {

            report.append("Sender: ")
                    .append(message.getSender())
                    .append("\nRecipient: ")
                    .append(message.getRecipient())
                    .append("\n\n");
        }

        return report.toString();
    }

    // Finds and displays the longest stored message.
    public String displayLongestStoredMessage() {

        if (storedMessages.length == 0) {
            return "There are no stored messages.";
        }

        Message longest = storedMessages[0];

        for (Message message : storedMessages) {

            if (message.getMessage().length()
                    > longest.getMessage().length()) {

                longest = message;
            }
        }

        return longest.printMessages();
    }

    // Searches for a stored message using its message ID.
    public Message searchStoredMessageByID(String messageID) {

        for (Message message : storedMessages) {

            if (message.getMessageID().equals(messageID)) {
                return message;
            }
        }

        return null;
    }

    // Searches for all stored messages belonging to a recipient.
    public String searchStoredMessagesByRecipient(String recipient) {

        StringBuilder results = new StringBuilder();

        boolean found = false;

        for (Message message : storedMessages) {

            if (message.getRecipient().equals(recipient)) {

                results.append(message.printMessages())
                        .append("\n\n");

                found = true;
            }
        }

        if (!found) {
            return "No stored messages found for this recipient.";
        }

        return results.toString();
    }

    // Deletes a stored message using its message hash.
    public String deleteStoredMessageByHash(String messageHash) {

        int position = -1;

        for (int i = 0; i < storedMessages.length; i++) {

            if (storedMessages[i].getMessageHash()
                    .equals(messageHash)) {

                position = i;
                break;
            }
        }

        if (position == -1) {
            return "Message hash not found.";
        }

        Message[] updatedMessages =
                new Message[storedMessages.length - 1];

        int newIndex = 0;

        for (int i = 0; i < storedMessages.length; i++) {

            if (i != position) {
                updatedMessages[newIndex] = storedMessages[i];
                newIndex++;
            }
        }

        storedMessages = updatedMessages;

        if (saveStoredMessages()) {

            updateMessageDetails();

            return "Message successfully deleted.";

        } else {

            loadStoredMessages();

            return "Message could not be deleted.";
        }
    }

    // Displays a report containing all stored message details.
    public String displayStoredMessageReport() {

        StringBuilder report = new StringBuilder();

        if (storedMessages.length == 0) {
            return "There are no stored messages.";
        }

        report.append("STORED MESSAGE REPORT\n");
        report.append("=====================\n\n");

        for (Message message : storedMessages) {

            report.append(message.printMessages())
                    .append("\nStatus: ")
                    .append(message.getMessageStatus())
                    .append("\n\n");
        }

        return report.toString();
    }

    // Saves the updated stored message array to JSON.
    private boolean saveStoredMessages() {

        try {

            StringBuilder json = new StringBuilder("[\n");

            for (int i = 0; i < storedMessages.length; i++) {

                Message message = storedMessages[i];

                json.append("  {\n")
                        .append("    \"messageID\": \"")
                        .append(escapeJson(message.getMessageID()))
                        .append("\",\n")
                        .append("    \"messageNumber\": ")
                        .append(message.getMessageNumber())
                        .append(",\n")
                        .append("    \"recipient\": \"")
                        .append(escapeJson(message.getRecipient()))
                        .append("\",\n")
                        .append("    \"sender\": \"")
                        .append(escapeJson(message.getSender()))
                        .append("\",\n")
                        .append("    \"message\": \"")
                        .append(escapeJson(message.getMessage()))
                        .append("\",\n")
                        .append("    \"messageHash\": \"")
                        .append(escapeJson(message.getMessageHash()))
                        .append("\"\n")
                        .append("  }");

                if (i < storedMessages.length - 1) {
                    json.append(",");
                }

                json.append("\n");
            }

            json.append("]");

            Path parent = JSON_FILE.getParent();

            if (parent != null) {
                Files.createDirectories(parent);
            }

            Files.writeString(JSON_FILE, json.toString());

            return true;

        } catch (IOException e) {

            System.out.println(
                    "JSON storage error: " + e.getMessage()
            );

            return false;
        }
    }

    // Escapes special characters before saving JSON.
    private String escapeJson(String value) {

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Returns the sent messages array.
    public Message[] getSentMessages() {
        return sentMessages;
    }

    // Returns the disregarded messages array.
    public Message[] getDisregardedMessages() {
        return disregardedMessages;
    }

    // Returns the stored messages array.
    public Message[] getStoredMessages() {
        return storedMessages;
    }

    // Returns the message hashes array.
    public String[] getMessageHashes() {
        return messageHashes;
    }

    // Returns the message IDs array.
    public String[] getMessageIDs() {
        return messageIDs;
    }
}